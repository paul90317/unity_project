﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOverPanel : MonoBehaviour {

	void Start () {
        gameObject.SetActive(false);
	}
}
