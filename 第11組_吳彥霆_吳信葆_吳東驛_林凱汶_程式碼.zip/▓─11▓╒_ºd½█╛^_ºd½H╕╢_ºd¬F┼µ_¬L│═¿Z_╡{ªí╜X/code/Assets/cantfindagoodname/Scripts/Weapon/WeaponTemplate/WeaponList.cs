﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponList : MonoBehaviour {
    [SerializeField]
    public List<Weapon> weapons;
}
