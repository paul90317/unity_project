﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SFX : MonoBehaviour {
    public AudioClip shoot, hit, shootBeam;
}
