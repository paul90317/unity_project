﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClassList : MonoBehaviour {
    [SerializeField]
    public List<GameObject> classes;
}
