﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class AbstractClasses : MonoBehaviour {
    public Sprite spr;
    public abstract void skill();
}
