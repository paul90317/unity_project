﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ranger : AbstractClasses {
    public override void skill()
    {
        throw new System.NotImplementedException();
    }
}
