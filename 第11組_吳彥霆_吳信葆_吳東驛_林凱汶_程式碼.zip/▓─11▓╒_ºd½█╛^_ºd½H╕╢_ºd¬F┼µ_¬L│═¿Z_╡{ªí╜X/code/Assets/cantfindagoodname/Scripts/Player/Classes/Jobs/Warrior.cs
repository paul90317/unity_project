﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Warrior : AbstractClasses {
    public override void skill()
    {
        throw new System.NotImplementedException();
    }
}
