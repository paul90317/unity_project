﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tank : AbstractClasses {
    public override void skill()
    {
        throw new System.NotImplementedException();
    }
}
