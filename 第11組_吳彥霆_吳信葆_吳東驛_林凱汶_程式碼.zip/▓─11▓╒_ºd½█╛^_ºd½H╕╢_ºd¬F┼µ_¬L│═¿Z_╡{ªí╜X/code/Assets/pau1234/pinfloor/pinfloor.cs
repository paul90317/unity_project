﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pinfloor : MonoBehaviour {

    public int damage;
    public int coolDown;
    int cnt;
    static bool can_hurt;
	
    void Awake()
    {
        cnt = 0;
    }

    private void OnEnable()
    {
        cnt = coolDown;
        can_hurt = true;
    }
    private void OnDisable()
    {
        cnt = 0;
    }
    private void FixedUpdate()
    {
        cnt++;
        if (cnt >= coolDown)
        {
            can_hurt = true;
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (can_hurt && collision.tag == "Player")
        {
            cnt = 0;
            collision.gameObject.SendMessage("hurt", damage);
            Debug.Log("123");
            can_hurt = false;
        }
    }
}
