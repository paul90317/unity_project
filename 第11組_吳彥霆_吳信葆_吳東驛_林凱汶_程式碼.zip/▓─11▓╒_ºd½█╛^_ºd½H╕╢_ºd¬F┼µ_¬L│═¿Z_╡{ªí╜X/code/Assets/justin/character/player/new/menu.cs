﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class menu : MonoBehaviour
{
    public GameObject[] gs;
    public GameObject player;
    public void start()
    {
        for(int i = 0; i < gs.Length; i++)
        {
            Instantiate<GameObject>(gs[i]);
        }
        Instantiate<GameObject>(player);
        SceneManager.LoadScene(1);
    }
    
    
    public void exit()
    {
        Application.Quit();
    }
    public void back()
    {
        SceneManager.LoadScene(0);
    }
    
}
